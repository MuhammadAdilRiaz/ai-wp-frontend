<?php
/**
 * class-admin.php
 * Adds the AI Builder panel inside WordPress admin.
 * - Settings page: enter your app URL + connect site
 * - Chat panel: embedded iframe of your Next.js chat UI
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class AIWPB_Admin {

    public function __construct() {
        add_action( 'admin_menu',            [ $this, 'add_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'admin_post_aiwpb_save_settings', [ $this, 'save_settings' ] );
    }

    // ── Add sidebar menu item in WP admin ─────────────────────────────────────
    public function add_menu() {
        add_menu_page(
            'AI WP Builder',
            'AI Builder',
            'manage_options',
            'ai-wp-builder',
            [ $this, 'render_chat_page' ],
            'dashicons-superhero',
            3
        );

        add_submenu_page(
            'ai-wp-builder',
            'AI Builder — Chat',
            'Chat',
            'manage_options',
            'ai-wp-builder',
            [ $this, 'render_chat_page' ]
        );

        add_submenu_page(
            'ai-wp-builder',
            'AI Builder — Settings',
            'Settings',
            'manage_options',
            'ai-wp-builder-settings',
            [ $this, 'render_settings_page' ]
        );
    }

    // ── Load CSS + JS only on our plugin pages ────────────────────────────────
    public function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'ai-wp-builder' ) === false ) return;
        wp_enqueue_style(  'aiwpb-admin', AIWPB_PLUGIN_URL . 'admin/css/admin.css', [], AIWPB_VERSION );
        wp_enqueue_script( 'aiwpb-admin', AIWPB_PLUGIN_URL . 'admin/js/admin.js',  [], AIWPB_VERSION, true );

        // Pass data from PHP to JavaScript
        wp_localize_script( 'aiwpb-admin', 'AIWPB', [
            'site_url'   => get_site_url(),
            'site_token' => get_option( 'aiwpb_site_token' ),
            'app_url'    => get_option( 'aiwpb_app_url', '' ),
            'nonce'      => wp_create_nonce( 'aiwpb_nonce' ),
        ]);
    }

    // ── Chat page: embedded chat iframe from your Next.js app ─────────────────
    public function render_chat_page() {
        $app_url    = get_option( 'aiwpb_app_url', '' );
        $site_token = get_option( 'aiwpb_site_token' );
        $site_url   = urlencode( get_site_url() );

        if ( empty( $app_url ) ) {
            echo '<div class="wrap aiwpb-wrap">
                <div class="aiwpb-setup-notice">
                    <h2>🔧 Setup required</h2>
                    <p>Please go to <a href="' . admin_url('admin.php?page=ai-wp-builder-settings') . '">Settings</a> and enter your AI Builder app URL to get started.</p>
                </div>
            </div>';
            return;
        }

        // Build the URL for the iframe — pass site_url and token so the app knows which site
        $iframe_url = trailingslashit( $app_url ) . "chat?site_url={$site_url}&token={$site_token}";
        ?>
        <div class="wrap aiwpb-wrap">
            <div class="aiwpb-header">
                <h1><span class="aiwpb-logo">✦</span> AI WP Builder</h1>
                <div class="aiwpb-status" id="aiwpb-status">
                    <span class="aiwpb-dot"></span> Connecting...
                </div>
            </div>
            <div class="aiwpb-chat-container">
                <iframe
                    id="aiwpb-chat-frame"
                    src="<?php echo esc_url( $iframe_url ); ?>"
                    allow="clipboard-write"
                    title="AI WP Builder Chat"
                ></iframe>
            </div>
        </div>
        <?php
    }

    // ── Settings page: enter app URL, view token, copy connection info ─────────
    public function render_settings_page() {
        $app_url    = get_option( 'aiwpb_app_url', '' );
        $site_token = get_option( 'aiwpb_site_token' );
        $site_url   = get_site_url();
        $api_endpoint = $site_url . '/wp-json/aiwpb/v1/';

        $saved = isset( $_GET['saved'] ) && $_GET['saved'] === '1';
        ?>
        <div class="wrap aiwpb-wrap">
            <h1><span class="aiwpb-logo">✦</span> AI WP Builder — Settings</h1>

            <?php if ( $saved ) : ?>
                <div class="notice notice-success is-dismissible">
                    <p>Settings saved successfully.</p>
                </div>
            <?php endif; ?>

            <!-- Connection info box -->
            <div class="aiwpb-info-box">
                <h3>Your site connection details</h3>
                <p>Copy these into your AI Builder account to connect this WordPress site.</p>

                <table class="aiwpb-info-table">
                    <tr>
                        <th>Site URL</th>
                        <td>
                            <code><?php echo esc_html( $site_url ); ?></code>
                            <button class="aiwpb-copy-btn" data-copy="<?php echo esc_attr( $site_url ); ?>">Copy</button>
                        </td>
                    </tr>
                    <tr>
                        <th>API Endpoint</th>
                        <td>
                            <code><?php echo esc_html( $api_endpoint ); ?></code>
                            <button class="aiwpb-copy-btn" data-copy="<?php echo esc_attr( $api_endpoint ); ?>">Copy</button>
                        </td>
                    </tr>
                    <tr>
                        <th>Site Token</th>
                        <td>
                            <code class="aiwpb-token"><?php echo esc_html( $site_token ); ?></code>
                            <button class="aiwpb-copy-btn" data-copy="<?php echo esc_attr( $site_token ); ?>">Copy</button>
                        </td>
                    </tr>
                </table>

                <div class="aiwpb-connection-test">
                    <button id="aiwpb-test-btn" class="button button-secondary">Test Connection</button>
                    <span id="aiwpb-test-result"></span>
                </div>
            </div>

            <!-- Settings form -->
            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" class="aiwpb-settings-form">
                <?php wp_nonce_field( 'aiwpb_save_settings', 'aiwpb_nonce' ); ?>
                <input type="hidden" name="action" value="aiwpb_save_settings">

                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="aiwpb_app_url">Your AI Builder App URL</label>
                        </th>
                        <td>
                            <input
                                type="url"
                                id="aiwpb_app_url"
                                name="aiwpb_app_url"
                                value="<?php echo esc_attr( $app_url ); ?>"
                                placeholder="https://yourdomain.com"
                                class="regular-text"
                            />
                            <p class="description">The URL where your AI Builder Next.js app is deployed.</p>
                        </td>
                    </tr>
                </table>

                <p class="submit">
                    <button type="submit" class="button button-primary">Save Settings</button>
                </p>
            </form>

            <!-- Regenerate token (danger zone) -->
            <div class="aiwpb-danger-zone">
                <h3>Danger zone</h3>
                <p>Regenerating your token will disconnect all existing connections. You will need to reconnect your site in the AI Builder app.</p>
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" onsubmit="return confirm('Are you sure? This will disconnect your site.')">
                    <?php wp_nonce_field( 'aiwpb_regen_token', 'aiwpb_nonce' ); ?>
                    <input type="hidden" name="action" value="aiwpb_regen_token">
                    <button type="submit" class="button button-secondary aiwpb-danger-btn">Regenerate Token</button>
                </form>
            </div>
        </div>
        <?php
    }

    // ── Save settings from the form ───────────────────────────────────────────
    public function save_settings() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
        check_admin_referer( 'aiwpb_save_settings', 'aiwpb_nonce' );

        $app_url = esc_url_raw( $_POST['aiwpb_app_url'] ?? '' );
        update_option( 'aiwpb_app_url', $app_url );

        wp_redirect( admin_url( 'admin.php?page=ai-wp-builder-settings&saved=1' ) );
        exit;
    }
}

// ── Handle token regeneration ─────────────────────────────────────────────────
add_action( 'admin_post_aiwpb_regen_token', function() {
    if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
    check_admin_referer( 'aiwpb_regen_token', 'aiwpb_nonce' );
    update_option( 'aiwpb_site_token', wp_generate_uuid4() );
    wp_redirect( admin_url( 'admin.php?page=ai-wp-builder-settings&saved=1' ) );
    exit;
});
