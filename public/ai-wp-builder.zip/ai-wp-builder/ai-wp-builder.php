<?php
/**
 * Plugin Name: AI WP Builder
 * Plugin URI:  https://yourdomain.com
 * Description: Connect your WordPress site to your AI builder. Build pages with chat.
 * Version:     1.0.0
 * Author:      Your Name
 * License:     GPL-2.0+
 * Text Domain: ai-wp-builder
 */

// Block direct access
if ( ! defined( 'ABSPATH' ) ) exit;

// ─── Constants ───────────────────────────────────────────────────────────────
define( 'AIWPB_VERSION',    '1.0.0' );
define( 'AIWPB_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AIWPB_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// ─── Load files ──────────────────────────────────────────────────────────────
require_once AIWPB_PLUGIN_DIR . 'includes/class-api.php';
require_once AIWPB_PLUGIN_DIR . 'includes/class-abilities.php';
require_once AIWPB_PLUGIN_DIR . 'includes/class-admin.php';

// ─── Activation: generate a unique secret token for this site ────────────────
register_activation_hook( __FILE__, function() {
    if ( ! get_option( 'aiwpb_site_token' ) ) {
        update_option( 'aiwpb_site_token', wp_generate_uuid4() );
    }
});

// ─── Boot ─────────────────────────────────────────────────────────────────────
add_action( 'plugins_loaded', function() {
    new AIWPB_API();
    new AIWPB_Admin();
});
