<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class AIWPB_Abilities {

    public function run( string $action, array $params ) {
        switch ( $action ) {
            case 'create_page':
                return $this->create_page( $params );
            case 'update_page':
                return $this->update_page( $params );
            case 'delete_page':
                return $this->delete_page( $params );
            case 'update_site_option':
                return $this->update_site_option( $params );
            case 'create_elementor_page':
                return $this->create_elementor_page( $params );
            case 'update_elementor_page':
                return $this->update_elementor_page( $params );
            case 'upload_media_from_url':
                return $this->upload_media_from_url( $params );
            case 'set_homepage':
                return $this->set_homepage( $params );
            case 'create_menu':
                return $this->create_menu( $params );
            case 'add_menu_item':
                return $this->add_menu_item( $params );
            case 'list_plugins':
                return $this->list_plugins();
            case 'list_themes':
                return $this->list_themes();
            case 'activate_plugin':
                return $this->activate_plugin( $params );
            case 'install_plugin':
                return $this->install_plugin( $params );
            case 'activate_theme':
                return $this->activate_theme( $params );
            case 'install_theme':
                return $this->install_theme( $params );
            default:
                return new WP_Error( 'unknown_action', "Unknown action: {$action}", [ 'status' => 400 ] );
        }
    }

    private function create_page( array $p ) {
        $page_id = wp_insert_post([
            'post_type'    => 'page',
            'post_title'   => sanitize_text_field( $p['title'] ?? 'New Page' ),
            'post_content' => wp_kses_post( $p['content'] ?? '' ),
            'post_status'  => in_array( $p['status'] ?? '', ['publish','draft'], true ) ? $p['status'] : 'publish',
            'post_name'    => sanitize_title( $p['slug'] ?? $p['title'] ?? '' ),
        ], true );

        if ( is_wp_error( $page_id ) ) return $page_id;

        return [
            'page_id'  => $page_id,
            'url'      => get_permalink( $page_id ),
            'edit_url' => get_edit_post_link( $page_id, 'raw' ),
        ];
    }

    private function update_page( array $p ) {
        if ( empty( $p['page_id'] ) ) {
            return new WP_Error( 'missing_id', 'page_id is required', [ 'status' => 400 ] );
        }

        $data = [ 'ID' => intval( $p['page_id'] ) ];
        if ( isset( $p['title'] ) )   $data['post_title']   = sanitize_text_field( $p['title'] );
        if ( isset( $p['content'] ) ) $data['post_content'] = wp_kses_post( $p['content'] );
        if ( isset( $p['status'] ) )  $data['post_status']  = sanitize_text_field( $p['status'] );

        $result = wp_update_post( $data, true );
        if ( is_wp_error( $result ) ) return $result;

        return [ 'page_id' => $result, 'url' => get_permalink( $result ) ];
    }

    private function delete_page( array $p ) {
        if ( empty( $p['page_id'] ) ) {
            return new WP_Error( 'missing_id', 'page_id is required', [ 'status' => 400 ] );
        }
        $result = wp_delete_post( intval( $p['page_id'] ), false );
        return $result ? [ 'deleted' => true, 'trashed' => true ] : new WP_Error( 'delete_failed', 'Could not delete page' );
    }

    private function update_site_option( array $p ) {
        $allowed_options = [
            'blogname', 'blogdescription', 'admin_email',
            'blogpublic', 'default_category', 'posts_per_page',
        ];

        $key = sanitize_key( $p['key'] ?? '' );

        if ( ! in_array( $key, $allowed_options, true ) ) {
            return new WP_Error( 'forbidden_option', "Option '{$key}' cannot be changed", [ 'status' => 403 ] );
        }

        update_option( $key, sanitize_text_field( $p['value'] ?? '' ) );
        return [ 'updated' => $key, 'value' => get_option( $key ) ];
    }

    private function create_elementor_page( array $p ) {
        if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
            return new WP_Error( 'no_elementor', 'Elementor is not installed', [ 'status' => 400 ] );
        }

        $elementor_data = $p['elementor_data'] ?? '[]';
        json_decode( $elementor_data );
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'bad_json', 'elementor_data must be valid JSON', [ 'status' => 400 ] );
        }

        $page_id = wp_insert_post([
            'post_type'    => 'page',
            'post_title'   => sanitize_text_field( $p['title'] ?? 'New Page' ),
            'post_status'  => in_array( $p['status'] ?? '', ['publish','draft'], true ) ? $p['status'] : 'publish',
            'post_name'    => sanitize_title( $p['slug'] ?? $p['title'] ?? '' ),
            'post_content' => '',
        ], true );

        if ( is_wp_error( $page_id ) ) return $page_id;

        update_post_meta( $page_id, '_elementor_edit_mode', 'builder' );
        update_post_meta( $page_id, '_elementor_template_type', 'wp-page' );
        update_post_meta( $page_id, '_elementor_data', wp_slash( $elementor_data ) );
        delete_post_meta( $page_id, '_elementor_css' );

        return [
            'page_id'     => $page_id,
            'url'         => get_permalink( $page_id ),
            'edit_url'    => admin_url( "post.php?post={$page_id}&action=elementor" ),
            'preview_url' => get_preview_post_link( $page_id ),
        ];
    }

    private function update_elementor_page( array $p ) {
        if ( empty( $p['page_id'] ) ) {
            return new WP_Error( 'missing_id', 'page_id is required', [ 'status' => 400 ] );
        }

        $page_id        = intval( $p['page_id'] );
        $elementor_data = $p['elementor_data'] ?? '[]';

        json_decode( $elementor_data );
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            return new WP_Error( 'bad_json', 'elementor_data must be valid JSON', [ 'status' => 400 ] );
        }

        update_post_meta( $page_id, '_elementor_data', wp_slash( $elementor_data ) );
        delete_post_meta( $page_id, '_elementor_css' );

        return [
            'page_id'     => $page_id,
            'url'         => get_permalink( $page_id ),
            'preview_url' => get_preview_post_link( $page_id ),
        ];
    }

    private function upload_media_from_url( array $p ) {
        if ( ! aiwpb_setting_enabled( 'aiwpb_enable_media_uploads' ) ) {
            return new WP_Error( 'disabled', 'Media uploads are disabled in plugin settings', [ 'status' => 403 ] );
        }
        if ( empty( $p['url'] ) ) {
            return new WP_Error( 'missing_url', 'url is required', [ 'status' => 400 ] );
        }

        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $url = esc_url_raw( $p['url'] );
        if ( ! preg_match( '#^https://#i', $url ) ) {
            return new WP_Error( 'invalid_url', 'Only HTTPS media URLs are allowed', [ 'status' => 400 ] );
        }

        $filename = sanitize_file_name( $p['filename'] ?? basename( wp_parse_url( $url, PHP_URL_PATH ) ) );
        $tmp = download_url( $url );
        if ( is_wp_error( $tmp ) ) return $tmp;

        $file_array = [ 'name' => $filename, 'tmp_name' => $tmp ];
        $attachment_id = media_handle_sideload( $file_array, 0, sanitize_text_field( $p['title'] ?? $filename ) );

        if ( is_wp_error( $attachment_id ) ) {
            @unlink( $tmp );
            return $attachment_id;
        }

        return [ 'attachment_id' => $attachment_id, 'url' => wp_get_attachment_url( $attachment_id ) ];
    }

    private function set_homepage( array $p ) {
        if ( ! aiwpb_setting_enabled( 'aiwpb_enable_menu_homepage_updates' ) ) {
            return new WP_Error( 'disabled', 'Homepage updates are disabled in plugin settings', [ 'status' => 403 ] );
        }
        if ( empty( $p['page_id'] ) ) {
            return new WP_Error( 'missing_id', 'page_id is required', [ 'status' => 400 ] );
        }
        update_option( 'show_on_front', 'page' );
        update_option( 'page_on_front', intval( $p['page_id'] ) );
        return [ 'homepage_set' => true, 'page_id' => intval( $p['page_id'] ) ];
    }

    private function create_menu( array $p ) {
        if ( ! aiwpb_setting_enabled( 'aiwpb_enable_menu_homepage_updates' ) ) {
            return new WP_Error( 'disabled', 'Menu management is disabled in plugin settings', [ 'status' => 403 ] );
        }
        $menu_id = wp_create_nav_menu( sanitize_text_field( $p['name'] ?? 'Main Menu' ) );
        if ( is_wp_error( $menu_id ) ) return $menu_id;
        return [ 'menu_id' => $menu_id ];
    }

    private function add_menu_item( array $p ) {
        if ( ! aiwpb_setting_enabled( 'aiwpb_enable_menu_homepage_updates' ) ) {
            return new WP_Error( 'disabled', 'Menu management is disabled in plugin settings', [ 'status' => 403 ] );
        }
        if ( empty( $p['menu_id'] ) ) {
            return new WP_Error( 'missing_id', 'menu_id is required', [ 'status' => 400 ] );
        }

        $item_data = [
            'menu-item-title'  => sanitize_text_field( $p['title'] ?? 'Page' ),
            'menu-item-status' => 'publish',
        ];

        if ( ! empty( $p['page_id'] ) ) {
            $item_data['menu-item-object-id'] = intval( $p['page_id'] );
            $item_data['menu-item-object']    = 'page';
            $item_data['menu-item-type']      = 'post_type';
        } elseif ( ! empty( $p['url'] ) ) {
            $item_data['menu-item-url']  = esc_url_raw( $p['url'] );
            $item_data['menu-item-type'] = 'custom';
        }

        $item_id = wp_update_nav_menu_item( intval( $p['menu_id'] ), 0, $item_data );
        if ( is_wp_error( $item_id ) ) return $item_id;

        return [ 'item_id' => $item_id, 'menu_id' => intval( $p['menu_id'] ) ];
    }

    private function list_plugins() {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $active_plugins = get_option( 'active_plugins', [] );
        $plugins = [];
        foreach ( get_plugins() as $plugin_file => $plugin_data ) {
            $plugins[] = [
                'file'    => $plugin_file,
                'name'    => $plugin_data['Name'] ?? $plugin_file,
                'version' => $plugin_data['Version'] ?? '',
                'active'  => in_array( $plugin_file, $active_plugins, true ),
            ];
        }
        return [ 'plugins' => $plugins ];
    }

    private function list_themes() {
        $active = wp_get_theme()->get_stylesheet();
        $themes = [];
        foreach ( wp_get_themes() as $stylesheet => $theme ) {
            $themes[] = [
                'stylesheet' => $stylesheet,
                'name'       => $theme->get( 'Name' ),
                'version'    => $theme->get( 'Version' ),
                'active'     => $stylesheet === $active,
            ];
        }
        return [ 'themes' => $themes ];
    }

    private function activate_plugin( array $p ) {
        if ( ! aiwpb_setting_enabled( 'aiwpb_enable_plugin_management' ) ) {
            return new WP_Error( 'disabled', 'Plugin management is disabled in plugin settings', [ 'status' => 403 ] );
        }
        require_once ABSPATH . 'wp-admin/includes/plugin.php';

        $plugin_file = sanitize_text_field( $p['plugin_file'] ?? '' );
        if ( empty( $plugin_file ) ) {
            $slug = sanitize_title( $p['slug'] ?? '' );
            if ( empty( $slug ) ) {
                return new WP_Error( 'missing_plugin', 'plugin_file or slug is required', [ 'status' => 400 ] );
            }
            $allowed = $this->ensure_slug_allowed( $slug, 'plugin' );
        if ( is_wp_error( $allowed ) ) return $allowed;
            foreach ( array_keys( get_plugins() ) as $file ) {
                if ( strpos( $file, $slug . '/' ) === 0 || strpos( $file, '/' . $slug . '.php' ) !== false ) {
                    $plugin_file = $file;
                    break;
                }
            }
        }
        if ( empty( $plugin_file ) ) {
            return new WP_Error( 'not_found', 'Plugin file could not be resolved', [ 'status' => 404 ] );
        }

        $result = activate_plugin( $plugin_file );
        if ( is_wp_error( $result ) ) return $result;

        return [ 'activated' => true, 'plugin_file' => $plugin_file ];
    }

    private function install_plugin( array $p ) {
        if ( ! aiwpb_setting_enabled( 'aiwpb_enable_plugin_management' ) ) {
            return new WP_Error( 'disabled', 'Plugin management is disabled in plugin settings', [ 'status' => 403 ] );
        }
        $slug = sanitize_title( $p['slug'] ?? '' );
        if ( empty( $slug ) ) {
            return new WP_Error( 'missing_slug', 'Plugin slug is required', [ 'status' => 400 ] );
        }
        $allowed = $this->ensure_slug_allowed( $slug, 'plugin' );
        if ( is_wp_error( $allowed ) ) return $allowed;

        require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';

        $api = plugins_api( 'plugin_information', [ 'slug' => $slug, 'fields' => [ 'sections' => false ] ] );
        if ( is_wp_error( $api ) ) return $api;

        $skin = new Automatic_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader( $skin );
        $result = $upgrader->install( $api->download_link );
        if ( is_wp_error( $result ) ) return $result;
        if ( ! $result ) {
            return new WP_Error( 'install_failed', 'Plugin installation failed', [ 'status' => 500 ] );
        }

        return [ 'installed' => true, 'slug' => $slug, 'plugin_file' => $upgrader->plugin_info() ];
    }

    private function activate_theme( array $p ) {
        if ( ! aiwpb_setting_enabled( 'aiwpb_enable_theme_management' ) ) {
            return new WP_Error( 'disabled', 'Theme management is disabled in plugin settings', [ 'status' => 403 ] );
        }
        $stylesheet = sanitize_title( $p['stylesheet'] ?? $p['slug'] ?? '' );
        if ( empty( $stylesheet ) ) {
            return new WP_Error( 'missing_theme', 'stylesheet or slug is required', [ 'status' => 400 ] );
        }
        $allowed = $this->ensure_slug_allowed( $stylesheet, 'theme' );
        if ( is_wp_error( $allowed ) ) return $allowed;

        $theme = wp_get_theme( $stylesheet );
        if ( ! $theme->exists() ) {
            return new WP_Error( 'theme_not_found', 'Theme not found', [ 'status' => 404 ] );
        }
        switch_theme( $stylesheet );
        return [ 'activated' => true, 'stylesheet' => $stylesheet, 'theme' => $theme->get( 'Name' ) ];
    }

    private function install_theme( array $p ) {
        if ( ! aiwpb_setting_enabled( 'aiwpb_enable_theme_management' ) ) {
            return new WP_Error( 'disabled', 'Theme management is disabled in plugin settings', [ 'status' => 403 ] );
        }
        $slug = sanitize_title( $p['slug'] ?? '' );
        if ( empty( $slug ) ) {
            return new WP_Error( 'missing_slug', 'Theme slug is required', [ 'status' => 400 ] );
        }
        $allowed = $this->ensure_slug_allowed( $slug, 'theme' );
        if ( is_wp_error( $allowed ) ) return $allowed;

        require_once ABSPATH . 'wp-admin/includes/theme.php';
        require_once ABSPATH . 'wp-admin/includes/theme-install.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';

        $api = themes_api( 'theme_information', [ 'slug' => $slug, 'fields' => [ 'sections' => false ] ] );
        if ( is_wp_error( $api ) ) return $api;

        $skin = new Automatic_Upgrader_Skin();
        $upgrader = new Theme_Upgrader( $skin );
        $result = $upgrader->install( $api->download_link );
        if ( is_wp_error( $result ) ) return $result;
        if ( ! $result ) {
            return new WP_Error( 'install_failed', 'Theme installation failed', [ 'status' => 500 ] );
        }

        return [ 'installed' => true, 'slug' => $slug ];
    }

    private function ensure_slug_allowed( $slug, $type = 'plugin' ) {
        $option_key = $type === 'theme' ? 'aiwpb_allowed_themes' : 'aiwpb_allowed_plugins';
        $allowed = array_values( array_filter( preg_split( '/\r\n|\r|\n/', (string) get_option( $option_key, '' ) ) ) );
        $allowed = array_map( 'sanitize_title', $allowed );
        if ( ! in_array( sanitize_title( $slug ), $allowed, true ) ) {
            return new WP_Error( 'disallowed_slug', ucfirst( $type ) . ' slug is not approved in plugin settings', [ 'status' => 403 ] );
        }
        return true;
    }
}
