(function() {
    'use strict';

    function setStatus(connected, text) {
        var statusEl = document.getElementById('aiwpb-status');
        if (!statusEl) return;
        var dot = statusEl.querySelector('.aiwpb-dot');
        var textEl = statusEl.querySelector('.aiwpb-status-text') || statusEl;
        dot.classList.remove('connected', 'disconnected');
        dot.classList.add(connected ? 'connected' : 'disconnected');
        textEl.textContent = text;
    }

    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.aiwpb-copy-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var text = btn.getAttribute('data-copy');
                navigator.clipboard.writeText(text).then(function() {
                    btn.textContent = AIWPB.strings.copied;
                    btn.classList.add('copied');
                    setTimeout(function() {
                        btn.textContent = AIWPB.strings.copy;
                        btn.classList.remove('copied');
                    }, 1800);
                });
            });
        });

        var testBtn = document.getElementById('aiwpb-test-btn');
        var testResult = document.getElementById('aiwpb-test-result');

        function pingStatus(updateResult) {
            return fetch(AIWPB.status_url, {
                method: 'GET',
                headers: {
                    'X-AIWPB-Token': AIWPB.site_token,
                    'Content-Type': 'application/json'
                }
            })
            .then(function(res) { return res.json(); })
            .then(function(data) {
                var ok = !!data.connected;
                setStatus(ok, ok ? ('Connected to ' + (data.site_name || AIWPB.site_url)) : 'Disconnected');
                if (updateResult && testResult) {
                    testResult.textContent = ok ? ('✓ Connected — ' + data.site_name) : '✗ Could not connect';
                    testResult.className = ok ? 'success' : 'error';
                }
                return data;
            })
            .catch(function(err) {
                setStatus(false, 'Disconnected');
                if (updateResult && testResult) {
                    testResult.textContent = '✗ Error: ' + err.message;
                    testResult.className = 'error';
                }
                throw err;
            });
        }

        if (testBtn) {
            testBtn.addEventListener('click', function() {
                testBtn.disabled = true;
                if (testResult) {
                    testResult.textContent = 'Testing...';
                    testResult.className = '';
                }
                pingStatus(true).finally(function() {
                    testBtn.disabled = false;
                });
            });
        }

        if (document.getElementById('aiwpb-status')) {
            pingStatus(false);
        }

        window.addEventListener('message', function(event) {
            if (!AIWPB.app_url || event.origin !== AIWPB.app_url) return;
            var msg = event.data;
            if (!msg || !msg.type) return;
            if (msg.type === 'page_built' && msg.preview_url) {
                window.open(msg.preview_url, '_blank');
            }
            if (msg.type === 'open_elementor' && msg.edit_url) {
                window.open(msg.edit_url, '_blank');
            }
        });
    });
})();
