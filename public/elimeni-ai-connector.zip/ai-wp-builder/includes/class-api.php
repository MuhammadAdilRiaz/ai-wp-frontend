<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class AIWPB_API {

    public function __construct() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes() {
        register_rest_route( 'aiwpb/v1', '/action', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'handle_action' ],
            'permission_callback' => [ $this, 'verify_token' ],
        ]);

        register_rest_route( 'aiwpb/v1', '/status', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_status' ],
            'permission_callback' => [ $this, 'verify_token' ],
        ]);

        register_rest_route( 'aiwpb/v1', '/context', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_context' ],
            'permission_callback' => [ $this, 'verify_token' ],
        ]);

        register_rest_route( 'aiwpb/v1', '/preferences', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_preferences' ],
            'permission_callback' => [ $this, 'verify_token' ],
        ]);
    }

    public function verify_token( WP_REST_Request $request ) {
        $incoming_token = $request->get_header( 'X-AIWPB-Token' );
        $saved_token    = get_option( 'aiwpb_site_token' );

        if ( empty( $incoming_token ) || empty( $saved_token ) ) {
            return new WP_Error( 'no_token', 'Token missing', [ 'status' => 401 ] );
        }

        if ( ! hash_equals( $saved_token, $incoming_token ) ) {
            return new WP_Error( 'bad_token', 'Invalid token', [ 'status' => 403 ] );
        }

        return true;
    }

    public function handle_action( WP_REST_Request $request ) {
        $body   = $request->get_json_params();
        $action = sanitize_text_field( $body['action'] ?? '' );

        if ( empty( $action ) ) {
            return new WP_Error( 'no_action', 'No action provided', [ 'status' => 400 ] );
        }

        $abilities = new AIWPB_Abilities();
        $result    = $abilities->run( $action, is_array( $body ) ? $body : [] );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response([
            'success' => true,
            'action'  => $action,
            'result'  => $result,
        ]);
    }

    public function get_status( WP_REST_Request $request ) {
        $theme = wp_get_theme();
        return rest_ensure_response([
            'connected'    => true,
            'site_url'     => get_site_url(),
            'site_name'    => get_bloginfo( 'name' ),
            'wp_version'   => get_bloginfo( 'version' ),
            'elementor'    => defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : false,
            'wpbakery'     => defined( 'WPB_VC_VERSION' ) ? WPB_VC_VERSION : false,
            'divi'         => defined( 'ET_BUILDER_VERSION' ) ? ET_BUILDER_VERSION : false,
            'plugin_ver'   => AIWPB_VERSION,
            'theme'        => [
                'name'    => $theme->get( 'Name' ),
                'version' => $theme->get( 'Version' ),
                'stylesheet' => $theme->get_stylesheet(),
            ],
        ]);
    }

    public function get_preferences( WP_REST_Request $request ) {
        return rest_ensure_response( $this->format_preferences() );
    }

    public function get_context( WP_REST_Request $request ) {
        if ( ! aiwpb_setting_enabled( 'aiwpb_allow_site_inspection' ) ) {
            return new WP_Error( 'inspection_disabled', 'Site inspection is disabled in plugin settings', [ 'status' => 403 ] );
        }
        require_once ABSPATH . 'wp-admin/includes/plugin.php';

        $published_pages = get_posts([
            'post_type'      => 'page',
            'post_status'    => 'publish',
            'posts_per_page' => 50,
            'fields'         => 'ids',
        ]);

        $draft_pages = get_posts([
            'post_type'      => 'page',
            'post_status'    => 'draft',
            'posts_per_page' => 20,
            'fields'         => 'ids',
        ]);

        $page_list = array_map( function( $id ) {
            return [
                'id'          => $id,
                'title'       => get_the_title( $id ),
                'url'         => get_permalink( $id ),
                'slug'        => get_post_field( 'post_name', $id ),
                'builder'     => get_post_meta( $id, '_elementor_edit_mode', true ) ? 'elementor' : 'wordpress',
                'modified_gmt'=> get_post_field( 'post_modified_gmt', $id ),
            ];
        }, $published_pages );

        $draft_list = array_map( function( $id ) {
            return [
                'id'    => $id,
                'title' => get_the_title( $id ),
                'slug'  => get_post_field( 'post_name', $id ),
            ];
        }, $draft_pages );

        $theme = wp_get_theme();
        $menus = array_map( function( $m ) {
            return [ 'id' => $m->term_id, 'name' => $m->name, 'slug' => $m->slug ];
        }, wp_get_nav_menus() );

        $active_plugins = get_option( 'active_plugins', [] );
        $all_plugins    = get_plugins();
        $plugins        = [];
        foreach ( $all_plugins as $plugin_file => $plugin_data ) {
            $plugins[] = [
                'file'    => $plugin_file,
                'name'    => $plugin_data['Name'] ?? $plugin_file,
                'version' => $plugin_data['Version'] ?? '',
                'active'  => in_array( $plugin_file, $active_plugins, true ),
            ];
        }

        $installed_themes = wp_get_themes();
        $themes = [];
        foreach ( $installed_themes as $stylesheet => $theme_obj ) {
            $themes[] = [
                'stylesheet' => $stylesheet,
                'name'       => $theme_obj->get( 'Name' ),
                'version'    => $theme_obj->get( 'Version' ),
                'active'     => $stylesheet === $theme->get_stylesheet(),
            ];
        }

        $custom_logo_id = get_theme_mod( 'custom_logo' );
        $homepage_id    = (int) get_option( 'page_on_front' );
        $post_count     = (int) wp_count_posts( 'post' )->publish;
        $page_count     = (int) wp_count_posts( 'page' )->publish;

        $builder = 'classic';
        if ( defined( 'ELEMENTOR_VERSION' ) ) $builder = 'elementor';
        elseif ( defined( 'WPB_VC_VERSION' ) ) $builder = 'wpbakery';
        elseif ( defined( 'ET_BUILDER_VERSION' ) || function_exists( 'et_setup_theme' ) ) $builder = 'divi';

        $classification = $this->classify_site( $page_count, $post_count, $menus, $homepage_id, $builder, $plugins );

        return rest_ensure_response([
            'site_title'   => get_bloginfo( 'name' ),
            'site_tagline' => get_bloginfo( 'description' ),
            'site_url'     => get_site_url(),
            'theme'        => [
                'name'        => $theme->get( 'Name' ),
                'version'     => $theme->get( 'Version' ),
                'stylesheet'  => $theme->get_stylesheet(),
                'template'    => $theme->get_template(),
                'is_child'    => is_child_theme(),
            ],
            'themes'       => $themes,
            'pages'        => $page_list,
            'draft_pages'  => $draft_list,
            'menus'        => $menus,
            'plugins'      => $plugins,
            'elementor'    => defined( 'ELEMENTOR_VERSION' ),
            'wpbakery'     => defined( 'WPB_VC_VERSION' ),
            'divi'         => defined( 'ET_BUILDER_VERSION' ) || function_exists( 'et_setup_theme' ),
            'woocommerce'  => class_exists( 'WooCommerce' ),
            'builder'      => $builder,
            'homepage_id'  => $homepage_id,
            'homepage_url' => $homepage_id ? get_permalink( $homepage_id ) : '',
            'site_logo'    => $custom_logo_id ? wp_get_attachment_image_url( $custom_logo_id, 'full' ) : '',
            'counts'       => [
                'published_pages' => $page_count,
                'published_posts' => $post_count,
                'menus'           => count( $menus ),
                'plugins'         => count( $plugins ),
            ],
            'classification' => $classification,
            'preferences'    => $this->format_preferences(),
        ]);
    }

    private function format_preferences() {
        $settings = aiwpb_get_settings();
        return [
            'allow_site_inspection'        => $settings['aiwpb_allow_site_inspection'] === 'yes',
            'preserve_existing_site'       => $settings['aiwpb_preserve_existing_site'] === 'yes',
            'auto_setup_fresh_site'        => $settings['aiwpb_auto_setup_fresh_site'] === 'yes',
            'enable_plugin_management'     => $settings['aiwpb_enable_plugin_management'] === 'yes',
            'enable_theme_management'      => $settings['aiwpb_enable_theme_management'] === 'yes',
            'enable_media_uploads'         => $settings['aiwpb_enable_media_uploads'] === 'yes',
            'enable_menu_homepage_updates' => $settings['aiwpb_enable_menu_homepage_updates'] === 'yes',
            'enable_woocommerce'           => $settings['aiwpb_enable_woocommerce'] === 'yes',
            'default_builder'              => $settings['aiwpb_default_builder'],
            'prefer_existing_builder'      => $settings['aiwpb_prefer_existing_builder'] === 'yes',
            'allowed_plugins'              => array_values( array_filter( preg_split( '/\r\n|\r|\n/', $settings['aiwpb_allowed_plugins'] ) ) ),
            'allowed_themes'               => array_values( array_filter( preg_split( '/\r\n|\r|\n/', $settings['aiwpb_allowed_themes'] ) ) ),
            'brand_owner'                  => $settings['aiwpb_brand_owner'],
            'support_email'                => $settings['aiwpb_support_email'],
        ];
    }

    private function classify_site( $page_count, $post_count, $menus, $homepage_id, $builder, $plugins ) {
        $has_woocommerce = false;
        foreach ( $plugins as $plugin ) {
            if ( strtolower( $plugin['name'] ) === 'woocommerce' || stripos( $plugin['file'], 'woocommerce.php' ) !== false ) {
                $has_woocommerce = true;
                break;
            }
        }

        $score = 0;
        if ( $page_count > 0 ) $score++;
        if ( $post_count > 0 ) $score++;
        if ( ! empty( $menus ) ) $score++;
        if ( ! empty( $homepage_id ) ) $score++;
        if ( in_array( $builder, [ 'elementor', 'wpbakery', 'divi' ], true ) ) $score++;
        if ( $has_woocommerce ) $score++;

        if ( $score >= 3 ) {
            return 'existing';
        }
        if ( $score === 0 ) {
            return 'fresh';
        }
        return 'uncertain';
    }
}
