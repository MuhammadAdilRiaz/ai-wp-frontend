<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class AIWPB_Admin {

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'add_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'admin_post_aiwpb_save_settings', [ $this, 'save_settings' ] );
        add_action( 'admin_post_aiwpb_regen_token', [ $this, 'regenerate_token' ] );
    }

    public function add_menu() {
        add_menu_page(
            'Elimeni AI Connector',
            'Elimeni AI',
            'manage_options',
            'ai-wp-builder',
            [ $this, 'render_chat_page' ],
            'dashicons-superhero',
            3
        );

        add_submenu_page(
            'ai-wp-builder',
            'Elimeni AI — Chat',
            'Chat',
            'manage_options',
            'ai-wp-builder',
            [ $this, 'render_chat_page' ]
        );

        add_submenu_page(
            'ai-wp-builder',
            'Elimeni AI — Settings',
            'Settings',
            'manage_options',
            'ai-wp-builder-settings',
            [ $this, 'render_settings_page' ]
        );
    }

    public function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'ai-wp-builder' ) === false ) return;

        wp_enqueue_style( 'aiwpb-admin', AIWPB_PLUGIN_URL . 'admin/css/admin.css', [], AIWPB_VERSION );
        wp_enqueue_script( 'aiwpb-admin', AIWPB_PLUGIN_URL . 'admin/js/admin.js', [], AIWPB_VERSION, true );

        $settings = aiwpb_get_settings();
        $theme    = wp_get_theme();

        wp_localize_script( 'aiwpb-admin', 'AIWPB', [
            'site_url'   => get_site_url(),
            'site_token' => get_option( 'aiwpb_site_token' ),
            'app_url'    => get_option( 'aiwpb_app_url', '' ),
            'nonce'      => wp_create_nonce( 'aiwpb_nonce' ),
            'status_url' => rest_url( 'aiwpb/v1/status' ),
            'logo_url'   => AIWPB_PLUGIN_URL . 'assets/images/elimeni-ai-logo.png',
            'strings'    => [
                'copied' => 'Copied!',
                'copy'   => 'Copy',
            ],
            'site_summary' => [
                'theme'      => $theme->get( 'Name' ),
                'builder'    => $this->detect_primary_builder(),
                'inspection' => $settings['aiwpb_allow_site_inspection'],
            ],
        ] );
    }

    private function detect_primary_builder() {
        if ( defined( 'ELEMENTOR_VERSION' ) ) return 'Elementor';
        if ( defined( 'WPB_VC_VERSION' ) ) return 'WPBakery';
        if ( defined( 'ET_BUILDER_VERSION' ) || function_exists( 'et_setup_theme' ) ) return 'Divi';
        return 'Classic / Unknown';
    }

    private function render_brand_header( $title, $subtitle = '' ) {
        ?>
        <div class="aiwpb-shell">
            <div class="aiwpb-topbar">
                <div class="aiwpb-brand">
                    <img src="<?php echo esc_url( AIWPB_PLUGIN_URL . 'assets/images/elimeni-ai-logo.png' ); ?>" alt="Elimeni AI" class="aiwpb-brand-logo" />
                    <div>
                        <h1><?php echo esc_html( $title ); ?></h1>
                        <?php if ( $subtitle ) : ?>
                            <p><?php echo esc_html( $subtitle ); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="aiwpb-meta-badges">
                    <span class="aiwpb-badge aiwpb-badge-soft">Owner: <?php echo esc_html( get_option( 'aiwpb_brand_owner', 'Adil Riaz' ) ); ?></span>
                    <span class="aiwpb-badge">Developed by <a href="https://www.devoptex.com" target="_blank" rel="noopener noreferrer">Devoptex</a></span>
                </div>
            </div>
        <?php
    }

    public function render_chat_page() {
        $app_url    = get_option( 'aiwpb_app_url', '' );
        $site_token = get_option( 'aiwpb_site_token' );
        $site_url   = urlencode( get_site_url() );

        $this->render_brand_header( 'Elimeni AI Connector', 'Manage your WordPress site with Elimeni AI while preserving manual token-based connection.' );

        if ( empty( $app_url ) ) {
            echo '<div class="aiwpb-card aiwpb-empty-state">
                <h2>Setup required</h2>
                <p>Please open the Settings tab and enter your Elimeni AI app URL before launching the chat.</p>
                <p><a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=ai-wp-builder-settings' ) ) . '">Open Settings</a></p>
            </div></div>';
            return;
        }

        $iframe_url = trailingslashit( $app_url ) . 'chat?site_url=' . $site_url . '&token=' . rawurlencode( $site_token );
        ?>
        <div class="aiwpb-grid aiwpb-grid-two">
            <div class="aiwpb-card aiwpb-card-muted">
                <h3>Connection</h3>
                <ul class="aiwpb-list">
                    <li><strong>Manual token mode:</strong> Enabled and preserved.</li>
                    <li><strong>Site URL:</strong> <?php echo esc_html( get_site_url() ); ?></li>
                    <li><strong>Primary builder:</strong> <?php echo esc_html( $this->detect_primary_builder() ); ?></li>
                </ul>
            </div>
            <div class="aiwpb-card aiwpb-card-muted">
                <h3>Status</h3>
                <div class="aiwpb-status" id="aiwpb-status"><span class="aiwpb-dot"></span><span class="aiwpb-status-text">Checking connection...</span></div>
                <p class="description">The embedded SaaS chat remains compatible with your existing token workflow.</p>
            </div>
        </div>

        <div class="aiwpb-chat-card">
            <iframe
                id="aiwpb-chat-frame"
                src="<?php echo esc_url( $iframe_url ); ?>"
                allow="clipboard-write"
                title="Elimeni AI Chat"
            ></iframe>
        </div>
        </div>
        <?php
    }

    public function render_settings_page() {
        $settings      = aiwpb_get_settings();
        $site_token    = get_option( 'aiwpb_site_token' );
        $site_url      = get_site_url();
        $api_endpoint  = trailingslashit( $site_url ) . 'wp-json/aiwpb/v1/';
        $saved         = isset( $_GET['saved'] ) && $_GET['saved'] === '1';
        $theme         = wp_get_theme();

        $this->render_brand_header( 'Elimeni AI Settings', 'Control connection preferences, approved automation, builder defaults, and site inspection rules.' );
        ?>
        <?php if ( $saved ) : ?>
            <div class="notice notice-success is-dismissible"><p>Settings saved successfully.</p></div>
        <?php endif; ?>

        <div class="aiwpb-grid aiwpb-grid-three">
            <div class="aiwpb-card">
                <h3>Site Summary</h3>
                <div class="aiwpb-stat"><span>WordPress</span><strong><?php echo esc_html( get_bloginfo( 'version' ) ); ?></strong></div>
                <div class="aiwpb-stat"><span>Active Theme</span><strong><?php echo esc_html( $theme->get( 'Name' ) ); ?></strong></div>
                <div class="aiwpb-stat"><span>Builder</span><strong><?php echo esc_html( $this->detect_primary_builder() ); ?></strong></div>
            </div>
            <div class="aiwpb-card">
                <h3>Connection Details</h3>
                <table class="aiwpb-info-table">
                    <tr><th>Site URL</th><td><code><?php echo esc_html( $site_url ); ?></code><button class="aiwpb-copy-btn" data-copy="<?php echo esc_attr( $site_url ); ?>">Copy</button></td></tr>
                    <tr><th>API Endpoint</th><td><code><?php echo esc_html( $api_endpoint ); ?></code><button class="aiwpb-copy-btn" data-copy="<?php echo esc_attr( $api_endpoint ); ?>">Copy</button></td></tr>
                    <tr><th>Site Token</th><td><code class="aiwpb-token"><?php echo esc_html( $site_token ); ?></code><button class="aiwpb-copy-btn" data-copy="<?php echo esc_attr( $site_token ); ?>">Copy</button></td></tr>
                </table>
                <div class="aiwpb-connection-test">
                    <button id="aiwpb-test-btn" class="button button-secondary">Test Connection</button>
                    <span id="aiwpb-test-result"></span>
                </div>
            </div>
            <div class="aiwpb-card aiwpb-card-highlight">
                <h3>Connection Modes</h3>
                <p><strong>Manual token connection:</strong> always supported.</p>
                <p><strong>Secure authorization:</strong> can be added by your SaaS without removing manual token mode.</p>
                <p class="description">Existing download-plugin workflow remains intact.</p>
            </div>
        </div>

        <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" class="aiwpb-settings-form">
            <?php wp_nonce_field( 'aiwpb_save_settings', 'aiwpb_nonce' ); ?>
            <input type="hidden" name="action" value="aiwpb_save_settings">

            <div class="aiwpb-grid aiwpb-grid-two">
                <div class="aiwpb-card">
                    <h3>SaaS & Branding</h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="aiwpb_app_url">Elimeni AI App URL</label></th>
                            <td>
                                <input type="url" id="aiwpb_app_url" name="aiwpb_app_url" value="<?php echo esc_attr( $settings['aiwpb_app_url'] ); ?>" placeholder="https://your-saas.com" class="regular-text" />
                                <p class="description">Used for the embedded chat and your SaaS connection flow.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="aiwpb_brand_owner">Brand Owner</label></th>
                            <td><input type="text" id="aiwpb_brand_owner" name="aiwpb_brand_owner" value="<?php echo esc_attr( $settings['aiwpb_brand_owner'] ); ?>" class="regular-text" /></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="aiwpb_support_email">Support Email</label></th>
                            <td><input type="email" id="aiwpb_support_email" name="aiwpb_support_email" value="<?php echo esc_attr( $settings['aiwpb_support_email'] ); ?>" class="regular-text" /></td>
                        </tr>
                    </table>
                </div>

                <div class="aiwpb-card">
                    <h3>Workflow Preferences</h3>
                    <table class="form-table aiwpb-toggle-table">
                        <?php $this->toggle_row( 'Allow site inspection', 'aiwpb_allow_site_inspection', $settings['aiwpb_allow_site_inspection'], 'Allow Elimeni AI to inspect themes, plugins, pages, menus, homepage, and builder context in read-only mode.' ); ?>
                        <?php $this->toggle_row( 'Preserve existing websites', 'aiwpb_preserve_existing_site', $settings['aiwpb_preserve_existing_site'], 'Recommended. Existing websites should not be changed automatically.' ); ?>
                        <?php $this->toggle_row( 'Auto setup fresh websites', 'aiwpb_auto_setup_fresh_site', $settings['aiwpb_auto_setup_fresh_site'], 'Allow automatic setup when the SaaS detects a fresh WordPress site and the user requests a new site.' ); ?>
                        <?php $this->toggle_row( 'Allow homepage and menu updates', 'aiwpb_enable_menu_homepage_updates', $settings['aiwpb_enable_menu_homepage_updates'], 'Lets the SaaS set homepage, create menus, and add menu items.' ); ?>
                    </table>
                </div>
            </div>

            <div class="aiwpb-grid aiwpb-grid-two">
                <div class="aiwpb-card">
                    <h3>Builder & Commerce Preferences</h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="aiwpb_default_builder">Default Builder</label></th>
                            <td>
                                <select id="aiwpb_default_builder" name="aiwpb_default_builder">
                                    <option value="elementor" <?php selected( $settings['aiwpb_default_builder'], 'elementor' ); ?>>Elementor</option>
                                    <option value="wpbakery" <?php selected( $settings['aiwpb_default_builder'], 'wpbakery' ); ?>>WPBakery</option>
                                    <option value="divi" <?php selected( $settings['aiwpb_default_builder'], 'divi' ); ?>>Divi</option>
                                    <option value="auto" <?php selected( $settings['aiwpb_default_builder'], 'auto' ); ?>>Auto detect / SaaS decides</option>
                                </select>
                                <p class="description">Elementor remains the best default for fresh websites.</p>
                            </td>
                        </tr>
                        <?php $this->toggle_row( 'Prefer existing builder', 'aiwpb_prefer_existing_builder', $settings['aiwpb_prefer_existing_builder'], 'If a builder already exists, your SaaS should prefer it rather than switching automatically.' ); ?>
                        <?php $this->toggle_row( 'Enable plugin management', 'aiwpb_enable_plugin_management', $settings['aiwpb_enable_plugin_management'], 'Allow approved plugin installation and activation actions.' ); ?>
                        <?php $this->toggle_row( 'Enable theme management', 'aiwpb_enable_theme_management', $settings['aiwpb_enable_theme_management'], 'Allow approved theme installation and activation actions.' ); ?>
                        <?php $this->toggle_row( 'Enable media uploads', 'aiwpb_enable_media_uploads', $settings['aiwpb_enable_media_uploads'], 'Allow image/media sideloading from approved URLs.' ); ?>
                        <?php $this->toggle_row( 'Enable WooCommerce management', 'aiwpb_enable_woocommerce', $settings['aiwpb_enable_woocommerce'], 'Prepare the site for WooCommerce-related automation when backend support is added.' ); ?>
                    </table>
                </div>

                <div class="aiwpb-card">
                    <h3>Approved Install Sources</h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="aiwpb_allowed_plugins">Approved Plugin Slugs</label></th>
                            <td>
                                <textarea id="aiwpb_allowed_plugins" name="aiwpb_allowed_plugins" rows="8" class="large-text code"><?php echo esc_textarea( $settings['aiwpb_allowed_plugins'] ); ?></textarea>
                                <p class="description">One plugin slug per line. Only these slugs can be installed or activated through AI actions.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="aiwpb_allowed_themes">Approved Theme Slugs</label></th>
                            <td>
                                <textarea id="aiwpb_allowed_themes" name="aiwpb_allowed_themes" rows="6" class="large-text code"><?php echo esc_textarea( $settings['aiwpb_allowed_themes'] ); ?></textarea>
                                <p class="description">One theme slug per line. Add your future <code>elimeni-ai</code> theme slug here.</p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <p class="submit"><button type="submit" class="button button-primary button-hero">Save Settings</button></p>
        </form>

        <div class="aiwpb-danger-zone">
            <h3>Danger zone</h3>
            <p>Regenerating the site token will disconnect all existing token-based connections from your SaaS until the new token is saved there.</p>
            <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" onsubmit="return confirm('Are you sure? This will disconnect existing token-based connections.');">
                <?php wp_nonce_field( 'aiwpb_regen_token', 'aiwpb_nonce' ); ?>
                <input type="hidden" name="action" value="aiwpb_regen_token" />
                <button type="submit" class="button button-secondary aiwpb-danger-btn">Regenerate Token</button>
            </form>
        </div>
        </div>
        <?php
    }

    private function toggle_row( $label, $name, $value, $description = '' ) {
        ?>
        <tr>
            <th scope="row"><?php echo esc_html( $label ); ?></th>
            <td>
                <label class="aiwpb-switch">
                    <input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="no" />
                    <input type="checkbox" name="<?php echo esc_attr( $name ); ?>" value="yes" <?php checked( $value, 'yes' ); ?> />
                    <span class="aiwpb-slider"></span>
                </label>
                <?php if ( $description ) : ?><p class="description"><?php echo esc_html( $description ); ?></p><?php endif; ?>
            </td>
        </tr>
        <?php
    }

    public function save_settings() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
        check_admin_referer( 'aiwpb_save_settings', 'aiwpb_nonce' );

        $defaults = aiwpb_get_default_settings();

        update_option( 'aiwpb_app_url', esc_url_raw( wp_unslash( $_POST['aiwpb_app_url'] ?? '' ) ) );
        update_option( 'aiwpb_brand_owner', sanitize_text_field( wp_unslash( $_POST['aiwpb_brand_owner'] ?? $defaults['aiwpb_brand_owner'] ) ) );
        update_option( 'aiwpb_support_email', sanitize_email( wp_unslash( $_POST['aiwpb_support_email'] ?? $defaults['aiwpb_support_email'] ) ) );

        $toggle_fields = [
            'aiwpb_allow_site_inspection',
            'aiwpb_preserve_existing_site',
            'aiwpb_auto_setup_fresh_site',
            'aiwpb_enable_plugin_management',
            'aiwpb_enable_theme_management',
            'aiwpb_enable_media_uploads',
            'aiwpb_enable_menu_homepage_updates',
            'aiwpb_enable_woocommerce',
            'aiwpb_prefer_existing_builder',
        ];

        foreach ( $toggle_fields as $field ) {
            $value = isset( $_POST[ $field ] ) && wp_unslash( $_POST[ $field ] ) === 'yes' ? 'yes' : 'no';
            update_option( $field, $value );
        }

        $builder = sanitize_key( wp_unslash( $_POST['aiwpb_default_builder'] ?? $defaults['aiwpb_default_builder'] ) );
        $allowed_builders = [ 'elementor', 'wpbakery', 'divi', 'auto' ];
        if ( ! in_array( $builder, $allowed_builders, true ) ) {
            $builder = 'elementor';
        }
        update_option( 'aiwpb_default_builder', $builder );

        update_option( 'aiwpb_allowed_plugins', $this->sanitize_slug_list( wp_unslash( $_POST['aiwpb_allowed_plugins'] ?? $defaults['aiwpb_allowed_plugins'] ) ) );
        update_option( 'aiwpb_allowed_themes', $this->sanitize_slug_list( wp_unslash( $_POST['aiwpb_allowed_themes'] ?? $defaults['aiwpb_allowed_themes'] ) ) );

        wp_safe_redirect( admin_url( 'admin.php?page=ai-wp-builder-settings&saved=1' ) );
        exit;
    }

    private function sanitize_slug_list( $raw ) {
        $items = preg_split( '/\r\n|\r|\n/', (string) $raw );
        $items = array_filter( array_map( function( $item ) {
            return sanitize_title( trim( $item ) );
        }, $items ) );
        return implode( "\n", array_unique( $items ) );
    }

    public function regenerate_token() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
        check_admin_referer( 'aiwpb_regen_token', 'aiwpb_nonce' );
        update_option( 'aiwpb_site_token', wp_generate_uuid4() );
        wp_safe_redirect( admin_url( 'admin.php?page=ai-wp-builder-settings&saved=1' ) );
        exit;
    }
}
