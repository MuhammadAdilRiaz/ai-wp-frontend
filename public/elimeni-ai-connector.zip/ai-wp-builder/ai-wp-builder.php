<?php
/**
 * Plugin Name: Elimeni AI Connector
 * Plugin URI:  https://www.devoptex.com
 * Description: Connect your WordPress site to Elimeni AI. Inspect your site, manage approved WordPress actions, and build pages with AI.
 * Version:     1.2.0
 * Author:      Elimeni
 * Author URI:  https://www.devoptex.com
 * Developer:   Devoptex
 * Developer URI: https://www.devoptex.com
 * License:     GPL-2.0+
 * Text Domain: ai-wp-builder
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'AIWPB_VERSION',    '1.2.0' );
define( 'AIWPB_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AIWPB_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'AIWPB_PLUGIN_FILE', __FILE__ );

require_once AIWPB_PLUGIN_DIR . 'includes/class-api.php';
require_once AIWPB_PLUGIN_DIR . 'includes/class-abilities.php';
require_once AIWPB_PLUGIN_DIR . 'includes/class-admin.php';

function aiwpb_get_default_settings() {
    return [
        'aiwpb_app_url'                     => '',
        'aiwpb_site_token'                  => '',
        'aiwpb_allow_site_inspection'       => 'yes',
        'aiwpb_preserve_existing_site'      => 'yes',
        'aiwpb_auto_setup_fresh_site'       => 'no',
        'aiwpb_enable_plugin_management'    => 'yes',
        'aiwpb_enable_theme_management'     => 'yes',
        'aiwpb_enable_media_uploads'        => 'yes',
        'aiwpb_enable_menu_homepage_updates'=> 'yes',
        'aiwpb_enable_woocommerce'          => 'no',
        'aiwpb_default_builder'             => 'elementor',
        'aiwpb_prefer_existing_builder'     => 'yes',
        'aiwpb_allowed_plugins'             => "elementor\nwoocommerce\nclassic-editor",
        'aiwpb_allowed_themes'              => "hello-elementor\nelimeni-ai",
        'aiwpb_support_email'               => 'support@devoptex.com',
        'aiwpb_brand_owner'                 => 'Adil Riaz',
    ];
}

function aiwpb_get_settings() {
    $settings = [];
    foreach ( aiwpb_get_default_settings() as $key => $default ) {
        $value = get_option( $key, $default );
        if ( $value === '' && $default !== '' ) {
            $value = $default;
        }
        $settings[ $key ] = $value;
    }
    return $settings;
}

function aiwpb_setting_enabled( $key ) {
    return get_option( $key, aiwpb_get_default_settings()[ $key ] ?? 'no' ) === 'yes';
}

register_activation_hook( __FILE__, function() {
    $defaults = aiwpb_get_default_settings();
    if ( ! get_option( 'aiwpb_site_token' ) ) {
        update_option( 'aiwpb_site_token', wp_generate_uuid4() );
    }
    foreach ( $defaults as $key => $default ) {
        if ( get_option( $key, null ) === null ) {
            update_option( $key, $default );
        }
    }
});

add_action( 'plugins_loaded', function() {
    new AIWPB_API();
    new AIWPB_Admin();
});
