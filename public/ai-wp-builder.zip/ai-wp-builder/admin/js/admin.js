/* AI WP Builder — Admin JS */
(function() {
    'use strict';

    document.addEventListener('DOMContentLoaded', function() {

        // ── Copy buttons ──────────────────────────────────────────────────────
        document.querySelectorAll('.aiwpb-copy-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var text = btn.getAttribute('data-copy');
                navigator.clipboard.writeText(text).then(function() {
                    btn.textContent = 'Copied!';
                    btn.classList.add('copied');
                    setTimeout(function() {
                        btn.textContent = 'Copy';
                        btn.classList.remove('copied');
                    }, 2000);
                });
            });
        });

        // ── Connection test button ────────────────────────────────────────────
        var testBtn    = document.getElementById('aiwpb-test-btn');
        var testResult = document.getElementById('aiwpb-test-result');

        if (testBtn) {
            testBtn.addEventListener('click', function() {
                testBtn.disabled = true;
                testResult.textContent = 'Testing...';
                testResult.className = '';

                // Call our own status endpoint to verify the API is working
                var statusUrl = AIWPB.site_url + '/wp-json/aiwpb/v1/status';

                fetch(statusUrl, {
                    method: 'GET',
                    headers: {
                        'X-AIWPB-Token': AIWPB.site_token,
                        'Content-Type': 'application/json',
                    }
                })
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.connected) {
                        testResult.textContent = '✓ Connected — ' + data.site_name;
                        testResult.className = 'success';
                    } else {
                        testResult.textContent = '✗ Could not connect';
                        testResult.className = 'error';
                    }
                })
                .catch(function(err) {
                    testResult.textContent = '✗ Error: ' + err.message;
                    testResult.className = 'error';
                })
                .finally(function() {
                    testBtn.disabled = false;
                });
            });
        }

        // ── Status dot on chat page ───────────────────────────────────────────
        var statusEl = document.getElementById('aiwpb-status');
        var dot      = statusEl ? statusEl.querySelector('.aiwpb-dot') : null;

        if (statusEl && AIWPB.site_url && AIWPB.site_token) {
            var statusUrl = AIWPB.site_url + '/wp-json/aiwpb/v1/status';

            fetch(statusUrl, {
                headers: { 'X-AIWPB-Token': AIWPB.site_token }
            })
            .then(function(r) { return r.json(); })
            .then(function(d) {
                if (d.connected) {
                    dot.classList.add('connected');
                    statusEl.childNodes[1].textContent = ' Connected';
                } else {
                    dot.classList.add('disconnected');
                    statusEl.childNodes[1].textContent = ' Disconnected';
                }
            })
            .catch(function() {
                dot.classList.add('disconnected');
                statusEl.childNodes[1].textContent = ' Disconnected';
            });
        }

        // ── Listen for messages from the iframe ───────────────────────────────
        // Your Next.js app can send messages like: { type: 'page_built', page_id: 123 }
        window.addEventListener('message', function(event) {
            if (!AIWPB.app_url || event.origin !== AIWPB.app_url) return;

            var msg = event.data;
            if (!msg || !msg.type) return;

            if (msg.type === 'page_built') {
                // Open preview in new tab when AI finishes building a page
                if (msg.preview_url) {
                    window.open(msg.preview_url, '_blank');
                }
            }

            if (msg.type === 'open_elementor') {
                // Open Elementor editor for a page
                if (msg.edit_url) {
                    window.open(msg.edit_url, '_blank');
                }
            }
        });

    });
})();
