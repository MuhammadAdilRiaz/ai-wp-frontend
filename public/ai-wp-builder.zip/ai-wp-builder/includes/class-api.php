<?php
/**
 * class-api.php
 * Registers REST API endpoints so your Node.js backend can send
 * AI actions to this WordPress site securely.
 *
 * Base URL: /wp-json/aiwpb/v1/
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class AIWPB_API {

    public function __construct() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    // ── Register all endpoints ────────────────────────────────────────────────
    public function register_routes() {

        // POST /wp-json/aiwpb/v1/action
        // Your backend sends AI actions here (create page, update option, etc.)
        register_rest_route( 'aiwpb/v1', '/action', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'handle_action' ],
            'permission_callback' => [ $this, 'verify_token' ],
        ]);

        // GET /wp-json/aiwpb/v1/status
        // Your backend calls this to check the site is connected and get info
        register_rest_route( 'aiwpb/v1', '/status', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_status' ],
            'permission_callback' => [ $this, 'verify_token' ],
        ]);

        // GET /wp-json/aiwpb/v1/context
        // Returns current site info so Claude knows what pages/settings exist
        register_rest_route( 'aiwpb/v1', '/context', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_context' ],
            'permission_callback' => [ $this, 'verify_token' ],
        ]);
    }

    // ── Token auth: every request must include X-AIWPB-Token header ──────────
    public function verify_token( WP_REST_Request $request ) {
        $incoming_token = $request->get_header( 'X-AIWPB-Token' );
        $saved_token    = get_option( 'aiwpb_site_token' );

        if ( empty( $incoming_token ) || empty( $saved_token ) ) {
            return new WP_Error( 'no_token', 'Token missing', [ 'status' => 401 ] );
        }

        if ( ! hash_equals( $saved_token, $incoming_token ) ) {
            return new WP_Error( 'bad_token', 'Invalid token', [ 'status' => 403 ] );
        }

        return true;
    }

    // ── Handle an AI action sent by your backend ──────────────────────────────
    public function handle_action( WP_REST_Request $request ) {
        $body   = $request->get_json_params();
        $action = sanitize_text_field( $body['action'] ?? '' );

        if ( empty( $action ) ) {
            return new WP_Error( 'no_action', 'No action provided', [ 'status' => 400 ] );
        }

        $abilities = new AIWPB_Abilities();
        $result    = $abilities->run( $action, $body );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response([
            'success' => true,
            'action'  => $action,
            'result'  => $result,
        ]);
    }

    // ── Status: confirm site is connected ─────────────────────────────────────
    public function get_status( WP_REST_Request $request ) {
        return rest_ensure_response([
            'connected'    => true,
            'site_url'     => get_site_url(),
            'site_name'    => get_bloginfo( 'name' ),
            'wp_version'   => get_bloginfo( 'version' ),
            'elementor'    => defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : false,
            'plugin_ver'   => AIWPB_VERSION,
        ]);
    }

    // ── Context: tell Claude what currently exists on this site ──────────────
    public function get_context( WP_REST_Request $request ) {
        // Get all published pages
        $pages = get_posts([
            'post_type'      => 'page',
            'post_status'    => 'publish',
            'posts_per_page' => 50,
            'fields'         => 'ids',
        ]);

        $page_list = array_map( function( $id ) {
            return [
                'id'    => $id,
                'title' => get_the_title( $id ),
                'url'   => get_permalink( $id ),
                'slug'  => get_post_field( 'post_name', $id ),
            ];
        }, $pages );

        // Get active theme
        $theme = wp_get_theme();

        // Get menus
        $menus = array_map( function( $m ) {
            return [ 'id' => $m->term_id, 'name' => $m->name ];
        }, wp_get_nav_menus() );

        return rest_ensure_response([
            'site_title'   => get_bloginfo( 'name' ),
            'site_tagline' => get_bloginfo( 'description' ),
            'site_url'     => get_site_url(),
            'theme'        => $theme->get( 'Name' ),
            'pages'        => $page_list,
            'menus'        => $menus,
            'elementor'    => defined( 'ELEMENTOR_VERSION' ),
            'homepage_id'  => get_option( 'page_on_front' ),
        ]);
    }
}
